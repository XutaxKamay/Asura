./clean.sh
./compile.sh
