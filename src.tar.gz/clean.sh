CXX='g++' make clean
CXX='g++ -m32' make clean
CXX='x86_64-w64-mingw32-g++' make clean
CXX='i686-w64-mingw32-g++' make clean
