#include "test.h"

int main()
{
    XLib::Test::run();
    return 0;
}
