#ifndef XLIB_H
#define XLIB_H

#include "circularbuffer.h"
#include "detourx86.h"
#include "hybridcrypto.h"
#include "memoryscanner.h"
#include "process.h"
#include "readbuffer.h"
#include "types.h"
#include "virtualtabletools.h"
#include "writebuffer.h"

#endif // XLIB_H
