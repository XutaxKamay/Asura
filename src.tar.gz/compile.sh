CXX='g++' make -j8 &
CXX='g++ -m32' make -j8 &
CXX='x86_64-w64-mingw32-g++' make -j8 &
CXX='i686-w64-mingw32-g++' make -j8 &
wait
